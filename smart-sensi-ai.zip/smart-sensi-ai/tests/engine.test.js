const assert = require('assert');
const E = require('../www/engine.js');
const base = { geral: 80, redDot: 75, x2: 70, x4: 60, awm: 40, olhadinha: 50 };
let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok -', name); };

t('dados incompletos pedem informação', () => {
  const r = E.diagnose({ values: { ...base, x4: '' }, situation: 'above' });
  assert(!r.ok && r.needs.includes('x4'));
});
t('passa da cabeça reduz, com limite por rodada', () => {
  const r = E.diagnose({ values: base, situation: 'above', severity: 3 });
  assert(r.ok);
  E.PARAMS.forEach(p => { assert(r.after[p] <= base[p]); assert(base[p] - r.after[p] <= E.MAX_STEP); });
  assert(r.after.geral < base.geral);
});
t('abaixo da cabeça aumenta', () => {
  const r = E.diagnose({ values: base, situation: 'below', severity: 2 });
  assert(r.ok && r.after.geral > base.geral);
});
t('escopo prioriza a mira afetada', () => {
  const r = E.diagnose({ values: base, situation: 'above', scope: 'x4', severity: 3 });
  assert(base.x4 - r.after.x4 > base.awm - r.after.awm);
});
t('valores ficam entre 0 e 100', () => {
  const r = E.diagnose({ values: { ...base, geral: 99 }, situation: 'below', severity: 3 });
  E.PARAMS.forEach(p => assert(r.after[p] >= 0 && r.after[p] <= 100));
});
t('instável detecta mira de longo alcance acima da anterior', () => {
  const r = E.diagnose({ values: { ...base, x4: 90 }, situation: 'unstable' });
  assert(r.ok && r.after.x4 < 90 && r.notes.length);
});
t('calibração sem sintoma pede dados', () => {
  const r = E.calibrate({ values: base, symptoms: {} });
  assert(!r.ok);
});
t('calibração: sintoma de passada reduz', () => {
  const r = E.calibrate({ values: base, symptoms: { overshoot: 3 } });
  assert(r.ok && r.after.geral < base.geral);
});
t('resultado "piorou" inverte o sentido com passo menor', () => {
  const hist = [{ key: 'calib', result: 'worse' }];
  const a = E.calibrate({ values: base, symptoms: { overshoot: 3 } });
  const b = E.calibrate({ values: base, symptoms: { overshoot: 3 }, history: hist });
  assert(b.after.geral > base.geral);
  assert(Math.abs(b.after.geral - base.geral) < Math.abs(a.after.geral - base.geral));
});
t('sintomas opostos geram aviso', () => {
  const r = E.calibrate({ values: base, symptoms: { overshoot: 2, tooSlow: 2 } });
  assert(r.ok && r.notes.some(x => x.includes('opostos')));
});
console.log(n + ' testes passaram');
